/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "marcotrillo@gmail.com" 

/* Define to the full name of this package. */
#define PACKAGE_NAME "LibAiff (MSVC)"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "LibAiff (MSVC) $Revision: 1.1 $"

/* Define to the version of this package. */ 
#define PACKAGE_VERSION "$Revision: 1.1 $"

