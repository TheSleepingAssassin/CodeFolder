#ifndef initializer_h
#define initializer_h 1
#include<vector>
#include "classes.h"
#define MODE GFX_AUTODETECT_WINDOWED
#define WIDTH 1000
#define HEIGHT 750
int initializegame();
//extern std::vector<objects *> objmap;
#endif
